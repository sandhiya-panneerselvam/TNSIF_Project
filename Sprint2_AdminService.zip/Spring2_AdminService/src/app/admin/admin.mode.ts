export interface Admin {
    id?:number;
    username:string;
    email:string;
    password:string;

}
